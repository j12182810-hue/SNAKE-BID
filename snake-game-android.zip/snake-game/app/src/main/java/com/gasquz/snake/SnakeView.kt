package com.gasquz.snake

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.random.Random

class SnakeView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    @Volatile private var running = false

    private val cellSize = 48
    private var cols = 0
    private var rows = 0

    private var snake = mutableListOf(Pair(5, 5))
    private var direction = Direction.RIGHT
    private var pendingDirection = Direction.RIGHT
    private var food = Pair(10, 10)
    private var score = 0
    private var gameOver = false
    private var moveIntervalMs = 150L
    private var lastMoveTime = 0L

    private var touchStartX = 0f
    private var touchStartY = 0f

    private val paintSnake = Paint().apply { color = Color.GREEN }
    private val paintFood = Paint().apply { color = Color.RED }
    private val paintBg = Paint().apply { color = Color.BLACK }
    private val paintText = Paint().apply {
        color = Color.WHITE
        textSize = 60f
        isAntiAlias = true
    }

    enum class Direction { UP, DOWN, LEFT, RIGHT }

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        cols = width / cellSize
        rows = height / cellSize
        spawnFood()
        running = true
        thread = Thread(this)
        thread?.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        cols = w / cellSize
        rows = h / cellSize
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join()
    }

    override fun run() {
        while (running) {
            val now = System.currentTimeMillis()
            if (!gameOver && now - lastMoveTime >= moveIntervalMs) {
                update()
                lastMoveTime = now
            }
            val canvas = holder.lockCanvas() ?: continue
            try {
                draw(canvas)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
            Thread.sleep(16)
        }
    }

    private fun update() {
        direction = pendingDirection
        val head = snake.first()
        var newHead = when (direction) {
            Direction.UP -> Pair(head.first, head.second - 1)
            Direction.DOWN -> Pair(head.first, head.second + 1)
            Direction.LEFT -> Pair(head.first - 1, head.second)
            Direction.RIGHT -> Pair(head.first + 1, head.second)
        }

        // wrap around edges
        newHead = Pair(
            (newHead.first + cols) % cols,
            (newHead.second + rows) % rows
        )

        if (snake.contains(newHead)) {
            gameOver = true
            return
        }

        snake.add(0, newHead)

        if (newHead == food) {
            score++
            spawnFood()
            if (moveIntervalMs > 60) moveIntervalMs -= 3
        } else {
            snake.removeAt(snake.size - 1)
        }
    }

    private fun spawnFood() {
        do {
            food = Pair(Random.nextInt(cols), Random.nextInt(rows))
        } while (snake.contains(food))
    }

    private fun draw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintBg)

        for (segment in snake) {
            canvas.drawRect(
                (segment.first * cellSize).toFloat(),
                (segment.second * cellSize).toFloat(),
                (segment.first * cellSize + cellSize).toFloat(),
                (segment.second * cellSize + cellSize).toFloat(),
                paintSnake
            )
        }

        canvas.drawRect(
            (food.first * cellSize).toFloat(),
            (food.second * cellSize).toFloat(),
            (food.first * cellSize + cellSize).toFloat(),
            (food.second * cellSize + cellSize).toFloat(),
            paintFood
        )

        canvas.drawText("Score: $score", 20f, 70f, paintText)

        if (gameOver) {
            canvas.drawText("GAME OVER - tap to restart", 40f, (height / 2).toFloat(), paintText)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = event.x
                touchStartY = event.y
                if (gameOver) restart()
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - touchStartX
                val dy = event.y - touchStartY
                if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                    if (dx > 50 && direction != Direction.LEFT) pendingDirection = Direction.RIGHT
                    else if (dx < -50 && direction != Direction.RIGHT) pendingDirection = Direction.LEFT
                } else {
                    if (dy > 50 && direction != Direction.UP) pendingDirection = Direction.DOWN
                    else if (dy < -50 && direction != Direction.DOWN) pendingDirection = Direction.UP
                }
            }
        }
        return true
    }

    private fun restart() {
        snake = mutableListOf(Pair(5, 5))
        direction = Direction.RIGHT
        pendingDirection = Direction.RIGHT
        score = 0
        moveIntervalMs = 150L
        gameOver = false
        spawnFood()
    }
}
